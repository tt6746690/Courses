This code is (c) Kyros Kutulakos, Jan 29, 2006

You do not need to know matlab to run the demo

To run the demo I showed in class:

  - type 'matlab' at the prompt on a CDF linux machine
  - once the matlab interface opens up, type 'polydemo' at
    the matlab prompt.
  - you will be asked a series of questions--just type 'enter'
    for the default values
  - the figure I showed in class will then open up. you should
    probably resize it to the full screen to see the graphs &
    text clearly
  - to make the window slide over one pixel, press enter
  - when the window hits the end of the row/column, the demo will
    apply the computation to all image rows/columns and display a
    second figure with three images (original, estimated, derivative)
    
There are no comments in the code, I just wrote this up a couple 
of days ago just to show it in class. I have not checked it thoroughly
for bugs, so use at your own risk!

kyros
