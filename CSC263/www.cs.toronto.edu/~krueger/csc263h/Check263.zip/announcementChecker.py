#! /usr/bin/python

import time
import urllib2
import os
from BeautifulSoup import BeautifulSoup

#Open the date file to check for last update.
try:
    annDate = file(os.environ['HOME'] + "/.annDates", "r")
    lastAnnouncement = annDate.readline()
    annDate.close();
except:
    lastAnnouncement = ""



# Record time of last attempt
lastCheck = open(os.environ['HOME'] + "/.lastCheck", "w+")
lastCheck.write(time.strftime("%x at %X\n"))

# Access CSC263 announcement page
page = urllib2.urlopen("http://www.cs.toronto.edu/~krueger/csc263h/announcements.html")
soup = BeautifulSoup(page)
pageAnnouncement = soup('h3')[0].contents[0].strip()
if (pageAnnouncement != lastAnnouncement.strip()):
    
    # New announcement exists on the web page - inform and open browser.
    annDate = file(os.environ['HOME'] + "/.annDates", "w")
    annDate.write(pageAnnouncement)
    print time.strftime("%x at %X") + " New Announcement Available"
    fireFox = "open -a FireFox http://www.cs.toronto.edu/~krueger/csc263h/announcements.html"
    os.system(fireFox)

annDate.close()
lastCheck.close()
print time.strftime("%x at %X") +" Done"